<?php

$reviews = file('reviews.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
foreach ($reviews as $review) {
    echo "<li>$review</li>";
}
?>
