<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   
    $name = htmlspecialchars($_POST['name']);
    $comment = htmlspecialchars($_POST['comment']);

    $review = "$name: $comment\n";
    file_put_contents('reviews.txt', $review, FILE_APPEND);
}
?>
