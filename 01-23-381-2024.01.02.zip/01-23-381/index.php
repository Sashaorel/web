<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title> Веб технології</title>
</head>
<body>
     <?php include "date.php" ?>
	<header class="header">
		<div class="All_header_menu">
			<div class="logo">
				<h1><a href="#">Cher17</a></h1>
			</div>
			<div class="Top_menu">
				<ul>
					<li><a href="#">Категорії</a></li>
					<li><font size="4"><a href="#">Кошик</a></font></li>
					<li><font size="4"><a href="#">Акаунт</a></font></li>


				</ul>
			</div>
		</div>
	</header>
	<main class="content">
		<div style="display: flex;">
		
			<div style="flex-grow: 1;">
				<img src="https://cher17.com/wp-content/uploads/2023/01/history-cher17-6.jpg" width="400" height="600">
			</div>
			<div style="flex-grow: 3;">
				<h2><font size="3"><div align="center">Привіт! Ми  – український масмаркет-бренд,
				 який заснували інфлюенсери й підприємці Тетяна Парфілієва та Іван Кришталь.Від ескізу до пакування – CHER’17 народжується саме в Україні.Кожні два тижні, не дивлячись на обставини, ми випускаємо нові моделі, аби дарувати тобі вибір. Бути у тренді, але відчувати себе зручно. Бути витонченою та кежуал одночасно. Ми робимо все, аби ти була одягнена влучно, неважливо де і коли. Кожен з команди у CHER’17 стежить за актуальними тенденціями та витримує планку якості, аби ти змогла обрати сукню дня, сяяти та залишитись при цьому собою.Саме тому нам у CHER’17 довіряють тисячі дівчат різних міст та країн. Сотні суконь та костюмів відправляються щодня, аби дістатись до пункту призначення у важливий момент. Момент, коли ти обираєш себе.В будь-якому настрої чи дрес-коді.
				 CHER’17: жіночно, бо по-справжньому.</div></font></h2>
				 <h3><center>Магазини</center></h3>
				<table color="blue" border="1">
					<tr>
						<th><center>Місто</center> </th>
						<th width="200" height="35">Адреса</th>
						<th width="200" height="35">Телефон</th>
					</tr>
					<tr>
						<td width="200" height="35">Київ</td>
						<td width="200" height="35">ТРЦ "Respublika Park"</td>
						<td width="200" height="35">+380977248787</td>
					</tr>
					<tr>
						<td width="200" height="35">Одеса</td>
						<td width="200" height="35">вул. Катерининська, 18</td>
						<td width="200" height="35">+380976905631</td>
					</tr>
					<tr>
						<td width="200" height="35">Дніпро</td>
						<td width="200" height="35">ТЦ "Європа"</td>
						<td width="200" height="35">+380983276759</td>
					</tr>
				</table>
				<button class="clickss"> 
					<a href="#" align="center"> Змінити колір</a>
				</button>
			

			</div>
			<div style="flex-grow: 1;">
				<div id="video">
					<img src="https://cher17.com/wp-content/uploads/2023/01/img_1717.jpg" width="300" height="500">
					<a href="https://youtu.be/cj4u2IUnuS0?si=S9R_bDaib5TMxv5b"><font size="5">Переглянути відео</font></a>
				</div>
				</div>
	</main>
	<div>
		<footer class="footer">
			<ul>
				<li><a href="#">facebook</a></li>
				<li><a href="#">Twitter</a></li>
                <li align="center"><a href="coments_form.php">Відгуки</a></li>
                
			</ul>
		 		
		</footer>
	</div>
	<script src="web5.js"> </script>
</body>
</html>