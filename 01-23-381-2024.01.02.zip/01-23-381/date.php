<?php
date_default_timezone_set('Europe/Kiev');
$currentDate = date('Y-m-d H:i:s');
echo "Поточна дата і час: $currentDate";
?>