<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <title>Залишити відгук</title>
    <script>
        function updateComments() {
            $.ajax({
                type: "GET",
                url: "get_comments.php", 
                success: function (data) {
                    $("#comments-list").html(data);
                }
            });
        }

        $(document).ready(function () {
            updateComments();
            
            $("#comment-form").submit(function (event) {
                event.preventDefault();
                $.ajax({
                    type: "POST",
                    url: "process_comment.php", 
                    data: $("#comment-form").serialize(),
                    success: function () {
                        updateComments();
                        $("#name").val("");
                        $("#comment").val("");
                    }
                });
            });
        });
    </script>
</head>
<body>
    <header class="header">
        
    </header>
    <main class="content">
        <h2>Залишити відгук</h2>
        <form id="comment-form">
            <label for="name">Ім'я:</label>
            <input type="text" id="name" name="name" required>
            <br>
            <label for="comment">Ваш відгук:</label>
            <textarea id="comment" name="comment" rows="4" required></textarea>
            <br>
            <button type="submit">Відправити відгук</button>
        </form>

        <h2>Коментарі</h2>
        <ul id="comments-list">
        </ul>
    </main>
</body>
</html>