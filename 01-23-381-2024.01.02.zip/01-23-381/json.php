<?php
$reviews = file('reviews.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$reviewsCount = count($reviews);
$jsonData = array('reviews' => $reviews, 'reviewsCount' => $reviewsCount);
header('Content-Type: application/json');
echo json_encode($jsonData, JSON_PRETTY_PRINT);
?>
