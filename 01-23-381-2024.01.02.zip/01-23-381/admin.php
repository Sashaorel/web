<?php
$jsonData = file_get_contents('http://lab.vntu.vn.ua/webusers/01-23-381/json.php');
$data = json_decode($jsonData, true);
if (empty($data)) {
    die('Помилка отримання даних або відсутні дані.');
}

echo "<h2>Коментарі:</h2>";
echo "<p>Кількість коментарів: " . $data['reviewsCount'] . "</p>";

if (!empty($data['reviews'])) {
    echo "<ul>";
    foreach ($data['reviews'] as $review) {
        echo "<li>$review</li>";
    }
    echo "</ul>";
} else {
    echo "<p>Немає коментарів.</p>";
}
?>


